<?php
//include_once 'db_functions.php';
//Create Object for DB_Functions clas
//$db = new DB_Functions(); 
$avGen = $_POST["availableCapMW"];
$peakGen = $_POST["peakGenMW"];
$avrGen = $_POST["averageGenMW"];
$gasCon = $_POST["gasConMW"];
$waterCon = $_POST["waterConMW"];
$loadCon = $_POST["loadConMW"];
$totalCon = $_POST["transConMW"];
$transCon = $_POST["totalConMW"];
$authCode = $_POST["authCode"];
$date = $_POST["date"];

$genco = $_POST["genco"];
$nipp = $_POST["nipp"];
$ipp = $_POST["ipp"];
$hydro = $_POST["hydro"];
$thermal = $_POST["thermal"];

$myAuth = 'iwin_admin';

$confirmUrl = "confirm-report.php";
$errorUrl = "error-report.php";
if($authCode == $myAuth){
	submitReport($avGen, $peakGen, $avrGen, $gasCon, $waterCon, $loadCon, $transCon, $totalCon, $date);
	submitChart($genco, $nipp, $ipp, $hydro, $thermal, $date);
}
else{
	echo "User not authorised";
}

function submitReport($avGen, $peakGen, $avrGen, $gasCon, $waterCon, $loadCon, $transCon, $totalCon, $date){
$host='localhost';
	$uname='iwin_mobile';
	$pwd='iwin_mobile_app12345';
	$db="iwin_iwin05";
		
	$con = mysqli_connect($host,$uname,$pwd,$db) or die("connection failed");
	
	$sql = "INSERT INTO generation_report (available_cap_mw, peak_gen_mw, average_gen_mw,gas_constr_mw, water_constr_mw, load_constr_mw, trans_constr_mw, total_constr_mw, date) VALUES('$avGen','$peakGen','$avrGen','$gasCon','$waterCon','$loadCon','$transCon','$totalCon','$date')";
	
	$res = mysqli_query($con, $sql) or die('Could not look up user information; ' . mysqli_error($con));
	//$res = $db->insertReport($avGen, $peakGen, $avrGen, $gasCon, $waterCon, $loadCon, $transCon, $totalCon);
	if ($res) {
		echo "Processing Chart data...";
	} else {
		echo "Processing Chart data...";
	}
	//close the db connection
    mysqli_close($con);
}

function submitChart($genco, $nipp, $ipp, $hydro, $thermal, $date){
$host='localhost';
	$uname='iwin_mobile';
	$pwd='iwin_mobile_app12345';
	$db="iwin_iwin05";
		
	$con = mysqli_connect($host,$uname,$pwd,$db) or die("connection failed");
	
	$sql = "INSERT INTO generation_report_chart (gencos, nipp, ipp,hydro, thermal,date) VALUES('$genco','$nipp','$ipp','$hydro','$thermal','$date')";
	
	$res = mysqli_query($con, $sql) or die('Could not look up user information; ' . mysqli_error($con));
	//$res = $db->insertReport($avGen, $peakGen, $avrGen, $gasCon, $waterCon, $loadCon, $transCon, $totalCon);
	if ($res) { ?>
		<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Power Generation Report</title>
	<link href="favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/form-validation.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

</head>


    <div class="main-content">

        <!-- You only need this form and the form-validation.css -->

        <form class="form-validation" method="post" action="powerreport.php" id="reportForm" style="margin-top:50px">

            <div class="form-title-row">
                <h2 style="color:green">Your report was submitted successfully.</h2>
            </div>

            
</body>

</html>
<?php
	} else {
	?>
	<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Power Generation Report</title>

 <link href="favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
	<link rel="stylesheet" href="assets/demo.css">
	<link rel="stylesheet" href="assets/form-validation.css">
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

</head>


    <div class="main-content">

        <!-- You only need this form and the form-validation.css -->

        <form class="form-validation" method="post" action="powerreport.php" id="reportForm" style="margin-top:50px">

            <div class="form-title-row">
                <h2 style="color:red">Your report was not submitted, please check the input  and try again</h2>
            </div>

            
</body>

</html>

	<?php
	}
	//close the db connection
    mysqli_close($con);
}

?>