<?php
/**
 * DB configuration variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "iwin_mobile");
define("DB_PASSWORD", "iwin_mobile_app12345");
define("DB_DATABASE", "iwin_iwin05");

/**
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyC9NQFk2sOczxeeisANwQ3VNm-L3M8USKc"); // Place your Google API Key
?>